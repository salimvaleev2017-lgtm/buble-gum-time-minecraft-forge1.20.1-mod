package net.mcreator.bublegumtime.item;

import net.minecraft.world.item.Item;

public class PillItem extends Item {
	public PillItem() {
		super(new Item.Properties());
	}
}