package net.mcreator.bublegumtime.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;

import net.mcreator.bublegumtime.procedures.OrbitPackOfGumRightclickedProcedure;

public class OrbitPackOfGumItem extends Item {
	public OrbitPackOfGumItem() {
		super(new Item.Properties().stacksTo(1).fireResistant());
	}

	@Override
	public boolean isPiglinCurrency(ItemStack stack) {
		return true;
	}

	@Override
	public boolean isCorrectToolForDrops(BlockState state) {
		return true;
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		OrbitPackOfGumRightclickedProcedure.execute(entity);
		return ar;
	}
}