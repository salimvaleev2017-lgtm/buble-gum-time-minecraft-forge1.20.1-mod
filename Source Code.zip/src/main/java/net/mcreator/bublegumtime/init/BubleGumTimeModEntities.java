/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bublegumtime.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.bublegumtime.entity.OrbitGumEntity;
import net.mcreator.bublegumtime.BubleGumTimeMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BubleGumTimeModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, BubleGumTimeMod.MODID);
	public static final RegistryObject<EntityType<OrbitGumEntity>> ORBIT_GUM = register("orbit_gum",
			EntityType.Builder.<OrbitGumEntity>of(OrbitGumEntity::new, MobCategory.MISC).setCustomClientFactory(OrbitGumEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}
}