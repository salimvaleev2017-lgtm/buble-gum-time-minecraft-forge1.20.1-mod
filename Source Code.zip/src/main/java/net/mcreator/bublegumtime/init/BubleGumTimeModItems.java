/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bublegumtime.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.bublegumtime.item.PillItem;
import net.mcreator.bublegumtime.item.OrbitPackOfGumItem;
import net.mcreator.bublegumtime.BubleGumTimeMod;

public class BubleGumTimeModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BubleGumTimeMod.MODID);
	public static final RegistryObject<Item> ORBIT_PACK_OF_GUM;
	public static final RegistryObject<Item> PILL;
	static {
		ORBIT_PACK_OF_GUM = REGISTRY.register("orbit_pack_of_gum", OrbitPackOfGumItem::new);
		PILL = REGISTRY.register("pill", PillItem::new);
	}
	// Start of user code block custom items
	// End of user code block custom items
}